"""
02_graficas.py
Genera las visualizaciones y las tablas resumen a partir de data/clean/cafes_tidy.csv.

Salidas:
  outputs/figuras/*.png      una figura por pregunta de investigación o variable
  outputs/tablas/*.csv       tablas con los conteos que muestran las figuras

Uso:  python scripts/02_graficas.py     (antes: python scripts/01_limpiar.py)

Si existe data/raw/distancias_equipamientos.csv, el script 01 agrega las distancias
a universidades, salud, oficinas y TransMilenio y este script dibuja además las
comparaciones "cerca frente a lejos" de las hipótesis H1, H2 y H4.
"""
import textwrap
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy import stats

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / "outputs" / "figuras"
TAB = ROOT / "outputs" / "tablas"
FIG.mkdir(parents=True, exist_ok=True)
TAB.mkdir(parents=True, exist_ok=True)

EXCLUIR_CERRADOS = False  # True: deja fuera las cafeterías marcadas como cerradas en el mapa
UMBRAL_M = 400
MIN_GRUPO = 4  # una comparación solo se hace si cada grupo tiene al menos 4 cafeterías

AZUL, GRIS, CLARO = "#2f6fb5", "#8a877e", "#cfe0f3"
plt.rcParams.update({
    "font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
    "axes.titleweight": "bold", "axes.titlesize": 11.5, "figure.dpi": 150,
})

df = pd.read_csv(ROOT / "data" / "clean" / "cafes_tidy.csv")
if EXCLUIR_CERRADOS:
    df = df[~df["cerrado_segun_nombre"]].copy()
N = len(df)
NOTA = f"n = {N} cafeterías. Fuente: encuesta a encargados de cada local, 2026."


def guardar(fig, nombre, nota=NOTA):
    """Guarda la figura con la nota al pie debajo de todo el contenido (ejes, etiquetas y leyendas)."""
    fig.canvas.draw()
    bb = fig.get_tightbbox(fig.canvas.get_renderer())
    ancho = max(fig.get_figwidth(), bb.width)
    nota = "\n".join(textwrap.wrap(nota, width=int(ancho * 13)))
    lineas = nota.count("\n") + 1
    fig.text(bb.x0 / fig.get_figwidth(), (bb.y0 - 0.12) / fig.get_figheight(), nota,
             fontsize=7.5, color=GRIS, ha="left", va="top", linespacing=1.3)
    fig.savefig(FIG / f"{nombre}.png", bbox_inches="tight", dpi=170, facecolor="white")
    plt.close(fig)
    print("  figura:", nombre)


def barras(serie, orden, titulo, nombre, xlabel="Número de cafeterías", color=AZUL, nota=NOTA):
    cuenta = serie.value_counts().reindex(orden, fill_value=0)
    cuenta.rename("cafeterias").to_csv(TAB / f"{nombre}.csv", encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(7, 0.55 * len(orden) + 1.6))
    y = np.arange(len(orden))[::-1]
    ax.barh(y, cuenta.values, color=color)
    ax.set_yticks(y, orden)
    for yi, v in zip(y, cuenta.values):
        ax.text(v + 0.1, yi, str(v), va="center", fontsize=9)
    ax.set_xlim(0, max(cuenta.max() + 1.5, 3))
    ax.set_xlabel(xlabel)
    ax.set_title(titulo, loc="left")
    guardar(fig, nombre, nota)


# ------------------------------------------------------------------ 01 mapa
def fig_mapa():
    lat0, lon0 = df["lat"].mean(), df["lon"].mean()
    d = df.reset_index(drop=True).copy()
    d["x"] = (d["lon"] - lon0) * 111320 * np.cos(np.radians(lat0))
    d["y"] = (d["lat"] - lat0) * 110574
    fig = plt.figure(figsize=(10.5, 7.5))
    gs = fig.add_gridspec(1, 2, width_ratios=[3.1, 1.25], wspace=0.04)
    ax, axl = fig.add_subplot(gs[0]), fig.add_subplot(gs[1])
    sc = ax.scatter(d["x"], d["y"], s=330, c=d["c2_punto_medio"], cmap="Blues", vmin=0, vmax=100,
                    edgecolor=AZUL, linewidth=1.3, zorder=3)
    sin = d["c2_punto_medio"].isna()
    ax.scatter(d.loc[sin, "x"], d.loc[sin, "y"], s=330, c="white", edgecolor=GRIS, linewidth=1.3, zorder=3)
    for i, r in d.iterrows():
        oscuro = pd.notna(r["c2_punto_medio"]) and r["c2_punto_medio"] > 55
        ax.text(r["x"], r["y"], str(i + 1), ha="center", va="center", fontsize=8.5, fontweight="bold",
                color="white" if oscuro else "black", zorder=4)
    ax.set_aspect("equal")
    ax.set_xlabel("Metros hacia el este desde el centro de la zona")
    ax.set_ylabel("Metros hacia el norte")
    ax.set_title("Ubicación de las cafeterías encuestadas", loc="left")
    cb = fig.colorbar(sc, ax=ax, orientation="horizontal", shrink=0.7, pad=0.1)
    cb.set_label("Parte de clientes que viene a propósito (punto medio, %). Blanco: sin dato")
    axl.axis("off")
    for i, r in d.iterrows():
        axl.text(0, 1 - i * 0.062, f"{i + 1}. {r['nombre_corto']}" + ("*" if r["cerrado_segun_nombre"] else ""),
                 fontsize=8.5, va="top", transform=axl.transAxes)
    nota = NOTA + " * Marcada como cerrada en el mapa. No hay mapa base: las posiciones son relativas."
    guardar(fig, "fig01_mapa_cafeterias", nota)


# ------------------------------------------------------------------ 02 importancia de factores
def fig_importancia():
    cols = {"b2_univ": "Cercanía a universidades", "b2_salud": "Cercanía a clínicas y hospitales",
            "b2_ofic": "Cercanía a oficinas", "b2_tm": "Cercanía a una estación de TransMilenio",
            "b2_cafes": "Tener otras cafeterías cerca", "b2_arriendo": "Precio del arriendo",
            "b2_calle": "Ambiente de la calle"}
    cont = pd.DataFrame({v: df[k].value_counts().reindex(range(1, 6), fill_value=0) for k, v in cols.items()}).T
    cont["media"] = [df[k].mean() for k in cols]
    cont = cont.sort_values("media")
    cont.round(2).to_csv(TAB / "fig02_importancia_factores.csv", encoding="utf-8-sig")
    colores = ["#e8f0fa", "#bcd3ee", "#86afdc", "#4f87c5", "#1f4f8a"]
    fig, ax = plt.subplots(figsize=(8.5, 4.6))
    izq = np.zeros(len(cont))
    for nivel, col in zip(range(1, 6), colores):
        ax.barh(cont.index, cont[nivel], left=izq, color=col, edgecolor="white", label=str(nivel))
        izq += cont[nivel].values
    for i, m in enumerate(cont["media"]):
        ax.text(N + 0.3, i, f"media {m:.1f}", va="center", fontsize=9)
    ax.set_xlim(0, N + 3)
    ax.set_xlabel("Número de cafeterías")
    ax.legend(title="1 = nada importante, 5 = muy importante", ncol=5, loc="upper center",
              bbox_to_anchor=(0.45, -0.16), frameon=False, fontsize=8, title_fontsize=8)
    ax.set_title("Qué tan importante fue cada factor al escoger el lugar", loc="left")
    guardar(fig, "fig02_importancia_factores", NOTA + " Razón declarada por el encargado, no una medida del entorno.")


# ------------------------------------------------------------------ 03 clientela
def fig_clientela():
    etq = {"cli_oficinas": "Trabajadores de oficinas cercanas", "cli_vecinos": "Vecinos del barrio",
           "cli_proposito": "Personas de otras zonas que vienen a propósito", "cli_estudiantes": "Estudiantes o profesores universitarios",
           "cli_salud": "Pacientes, acompañantes o personal de salud", "cli_turistas": "Turistas"}
    cuenta = pd.Series({v: int(df[k].sum()) for k, v in etq.items()}).sort_values()
    cuenta.rename("cafeterias").to_csv(TAB / "fig03_clientela.csv", encoding="utf-8-sig")
    fig, ax = plt.subplots(figsize=(8, 4))
    ax.barh(cuenta.index, cuenta.values, color=AZUL)
    for i, v in enumerate(cuenta.values):
        ax.text(v + 0.15, i, f"{v} de {N}", va="center", fontsize=9)
    ax.set_xlim(0, N + 3)
    ax.set_xlabel("Cafeterías que mencionan ese tipo de cliente entre sus más frecuentes")
    ax.set_title("Clientela frecuente según el encargado", loc="left")
    excede = int((df["c1_n"] > 3).sum())
    guardar(fig, "fig03_clientela", NOTA + f" El formulario pedía hasta tres opciones: {excede} cafeterías marcaron más.")


# ------------------------------------------------------------------ 06 horarios
def fig_horarios():
    orden = ["9-12pm", "12-2pm", "2-5pm", "5-8pm"]
    sem = df["c4_semana"].value_counts().reindex(orden, fill_value=0)
    fin = df["c4_finde"].value_counts().reindex(orden, fill_value=0)
    pd.DataFrame({"entre_semana": sem, "fin_de_semana": fin}).to_csv(TAB / "fig06_horarios.csv", encoding="utf-8-sig")
    x = np.arange(len(orden)); w = 0.38
    fig, ax = plt.subplots(figsize=(7.5, 4))
    b1 = ax.bar(x - w / 2, sem.values, w, label="Entre semana", color=AZUL)
    b2 = ax.bar(x + w / 2, fin.values, w, label="Fin de semana", color=CLARO, edgecolor=AZUL)
    for b in list(b1) + list(b2):
        ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.1, int(b.get_height()), ha="center", fontsize=9)
    ax.set_xticks(x, ["9:00 a 12:00", "12:00 a 14:00", "14:00 a 17:00", "17:00 a 20:00"])
    ax.set_ylabel("Número de cafeterías")
    ax.set_title("Franja de mayor afluencia declarada", loc="left")
    ax.legend(frameon=False)
    guardar(fig, "fig06_horarios", NOTA + " Estimación del encargado. Ninguna cafetería señaló 6:00 a 9:00 ni después de las 20:00.")


# ------------------------------------------------------------------ 08 aglomeración
def fig_aglomeracion():
    d = df.dropna(subset=["c2_punto_medio"])
    rho, p = stats.spearmanr(d["n_cafes_400"], d["c2_punto_medio"])
    fig, ax = plt.subplots(figsize=(7, 4.6))
    rng = np.random.default_rng(1)
    ax.scatter(d["n_cafes_400"] + rng.uniform(-0.12, 0.12, len(d)), d["c2_punto_medio"], s=80, color=AZUL, alpha=0.85)
    ax.set_xlabel(f"Otras cafeterías de la lista a {UMBRAL_M} m o menos")
    ax.set_ylabel("Clientes que vienen a propósito (punto medio, %)")
    ax.set_title("Aglomeración y clientela que llega a propósito (H3)", loc="left")
    ax.text(0.02, 0.04, f"Spearman: rho = {rho:.2f}, p = {p:.2f} (n = {len(d)})", transform=ax.transAxes, fontsize=9)
    pd.DataFrame({"nombre": d["nombre_corto"], "n_cafes_400": d["n_cafes_400"], "c2_punto_medio": d["c2_punto_medio"]}).to_csv(
        TAB / "fig08_aglomeracion.csv", index=False, encoding="utf-8-sig")
    guardar(fig, "fig08_aglomeracion", NOTA + " Exploratorio: con tan pocos locales el resultado no es concluyente. Las cafeterías se cuentan solo dentro de la lista.")
    return rho, p


# ------------------------------------------------------------------ 09 estudiantes y permanencia (aproximación a H1)
def fig_estudiantes_permanencia():
    fig, ax = plt.subplots(figsize=(6.5, 4.4))
    rng = np.random.default_rng(2)
    grupos = [("No los menciona", df[df["cli_estudiantes"] == 0]), ("Los menciona", df[df["cli_estudiantes"] == 1])]
    filas = []
    for i, (etq, g) in enumerate(grupos):
        ax.scatter(i + rng.uniform(-0.12, 0.12, len(g)), g["perm_orden"], s=70, color=AZUL, alpha=0.85, zorder=3)
        med = g["perm_orden"].median()
        ax.hlines(med, i - 0.25, i + 0.25, color="black", linewidth=2, zorder=4)
        filas.append({"grupo": etq, "n": len(g), "mediana_permanencia": med})
    ax.set_xticks([0, 1], [f"{e}\n(n = {len(g)})" for e, g in grupos])
    ax.set_yticks([1, 2, 3, 4], ["Menos de 30 min", "30 a 60 min", "1 a 2 horas", "Más de 2 horas"])
    ax.set_ylim(0.6, 4.4)
    ax.set_xlabel("¿Menciona a estudiantes o profesores entre sus clientes frecuentes?")
    ax.set_title("Permanencia declarada según clientela universitaria", loc="left")
    pd.DataFrame(filas).to_csv(TAB / "fig09_estudiantes_permanencia.csv", index=False, encoding="utf-8-sig")
    guardar(fig, "fig09_estudiantes_permanencia", NOTA + " Raya negra: mediana. Aproximación a H1 mientras no estén las distancias a universidades.")


# ------------------------------------------------------------------ 11 en adelante: comparaciones por entorno (si hay distancias)
def comparar_entornos():
    tipos = {"univ": ("universidad", "H1"), "TM": ("estación de TransMilenio", "H2"),
             "salud": ("clínica u hospital", "H4"), "ofic": ("zona de oficinas", "H4")}
    if not any(f"cerca_{t}" in df.columns for t in tipos):
        print("  (sin distancias a equipamientos: se omiten las figuras por entorno)")
        return
    resumen = []
    for t, (nombre, hip) in tipos.items():
        col = f"cerca_{t}"
        if col not in df.columns or df[col].notna().sum() == 0:
            continue
        d = df.dropna(subset=[col])
        n_cerca, n_lejos = int((d[col] == 1).sum()), int((d[col] == 0).sum())
        fig, axs = plt.subplots(1, 2, figsize=(9, 4.2))
        for ax, (var, etq, ticks) in zip(axs, [
                ("perm_orden", "Permanencia declarada", ([1, 2, 3, 4], ["< 30 min", "30-60", "1-2 h", "> 2 h"])),
                ("c2_punto_medio", "Clientes que vienen a propósito (%)", None)]):
            rng = np.random.default_rng(3)
            for i, (etq_g, g) in enumerate([("Lejos", d[d[col] == 0]), ("Cerca", d[d[col] == 1])]):
                ax.scatter(i + rng.uniform(-0.1, 0.1, len(g)), g[var], s=60, color=AZUL, alpha=0.85, zorder=3)
                if len(g):
                    ax.hlines(g[var].median(), i - 0.25, i + 0.25, color="black", linewidth=2, zorder=4)
            ax.set_xticks([0, 1], [f"Lejos\n(n = {n_lejos})", f"Cerca\n(n = {n_cerca})"])
            ax.set_ylabel(etq)
            if ticks:
                ax.set_yticks(*ticks)
            if min(n_cerca, n_lejos) < MIN_GRUPO:
                ax.text(0.5, 0.97, f"Un grupo tiene menos de {MIN_GRUPO}: solo descriptivo", transform=ax.transAxes,
                        ha="center", va="top", fontsize=8, color="#b03a2e")
        fig.suptitle(f"{hip}: cercanía a {nombre} (cerca = {UMBRAL_M} m o menos)", x=0.01, ha="left", fontweight="bold")
        guardar(fig, f"fig11_{hip.lower()}_{t.lower()}", NOTA + " Raya negra: mediana.")
        resumen.append({"hipotesis": hip, "entorno": nombre, "n_cerca": n_cerca, "n_lejos": n_lejos})
    pd.DataFrame(resumen).to_csv(TAB / "fig11_grupos_por_entorno.csv", index=False, encoding="utf-8-sig")


if __name__ == "__main__":
    print(f"Generando figuras para {N} cafeterías...")
    fig_mapa()
    fig_importancia()
    fig_clientela()
    barras(df["c2_proposito"], ["Del 0 al 25%", "Del 25 al 50%", "Del 50 al 75%", "Más de 75%", "No sabe"],
           "Parte de los clientes que viene a propósito desde fuera del barrio", "fig04_a_proposito",
           nota=NOTA + " Estimación del encargado. Los intervalos del formulario se solapan en 25 %, 50 % y 75 %.")
    barras(df["c3_llegada"], ["A pie", "Carro o moto", "TransMilenio o SITP", "Bicicleta", "No sabe"],
           "Cómo llega la mayoría de los clientes", "fig05_llegada", nota=NOTA + " Estimación del encargado.")
    fig_horarios()
    barras(df["c5_permanencia"], ["Menos de 30 minutos", "De 30-60 minutos", "De 1-2 horas", "Más de 2 horas"],
           "Tiempo que se queda un cliente en el local", "fig07_permanencia", nota=NOTA + " Estimación del encargado, no observación.")
    fig_aglomeracion()
    fig_estudiantes_permanencia()
    metodos = {"met_espresso": "Espresso", "met_leche": "Bebidas con leche", "met_v60": "V60", "met_chemex": "Chemex",
               "met_prensa": "Prensa francesa", "met_aeropress": "AeroPress", "met_frio": "Café frío"}
    serie = pd.Series({v: int(df[k].sum()) for k, v in metodos.items()}).sort_values(ascending=False)
    barras(pd.Series(np.repeat(serie.index, serie.values)), list(serie.index), "Métodos de preparación que ofrecen",
           "fig10_metodos", xlabel="Número de cafeterías que lo ofrecen")
    comparar_entornos()
    print("Listo. Figuras en outputs/figuras y tablas en outputs/tablas.")
