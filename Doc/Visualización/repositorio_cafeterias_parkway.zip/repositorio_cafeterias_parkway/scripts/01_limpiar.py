"""
01_limpiar.py
Limpia las respuestas del formulario y las une con el mapa de cafeterías.

Entradas  (data/raw):
  - Respuestas_encuesta.xlsx   exportación de Google Forms (una fila por cafetería)
  - Mapa_cafes.xlsx            lista de cafeterías con latitud, longitud y dirección
  - distancias_equipamientos.csv  (opcional) distancias medidas en el mapa, en metros:
        nombre,d_univ_m,d_salud_m,d_ofic_m,d_TM_m

Salidas (data/clean):
  - cafes_tidy.csv      una fila por cafetería, variables ya codificadas
  - calidad_datos.csv   alertas de calidad por cafetería

Uso:  python scripts/01_limpiar.py
"""
import math
import re
import unicodedata
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "data" / "raw"
CLEAN = ROOT / "data" / "clean"
CLEAN.mkdir(parents=True, exist_ok=True)

UMBRAL_M = 400  # una cafetería o equipamiento está "cerca" si queda a 400 m o menos

# ---------------------------------------------------------------- utilidades
def clave(texto):
    """Nombre sin tildes, en minúsculas y sin espacios sobrantes, para unir bases."""
    t = unicodedata.normalize("NFKD", str(texto)).encode("ascii", "ignore").decode()
    return re.sub(r"\s+", " ", t).strip().lower()


def haversine_m(lat1, lon1, lat2, lon2):
    """Distancia en línea recta, en metros, entre dos puntos."""
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lon2 - lon1)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * 6371000 * math.asin(math.sqrt(h))


def tiene(texto, opcion):
    """1 si la opción aparece en la respuesta de casillas (las opciones traen comas)."""
    return int(isinstance(texto, str) and opcion.lower() in texto.lower())


# ---------------------------------------------------------------- lectura
resp = pd.read_excel(RAW / "Respuestas_encuesta.xlsx")
if resp.columns[0].lower().startswith("marca temporal"):
    resp = resp.drop(columns=resp.columns[0])  # Google Forms agrega la marca de tiempo

NOMBRES = [
    "nombre", "en_parkway", "acepta", "mayor18", "vende_especialidad", "antiguedad",
    "local_tipo", "tuesta", "metodos", "origen",
    "b2_univ", "b2_salud", "b2_ofic", "b2_tm", "b2_cafes", "b2_arriendo", "b2_calle",
    "b3_percepcion", "b4_otras_zonas", "b4_cuales",
    "c1_clientes", "c2_proposito", "c3_llegada", "c4_semana", "c4_finde", "c5_permanencia",
]
if len(resp.columns) != len(NOMBRES):
    raise ValueError(
        f"Se esperaban {len(NOMBRES)} columnas y el archivo tiene {len(resp.columns)}. "
        "Revisen si el formulario cambió y ajusten la lista NOMBRES."
    )
resp.columns = NOMBRES
for c in resp.columns:
    if not pd.api.types.is_numeric_dtype(resp[c]):
        resp[c] = resp[c].astype("string").str.strip()

mapa = pd.read_excel(RAW / "Mapa_cafes.xlsx", usecols="A:F")
mapa.columns = ["nombre", "instagram", "lat", "lon", "google_maps", "direccion"]
mapa["lat"] = pd.to_numeric(mapa["lat"], errors="coerce")
mapa["lon"] = pd.to_numeric(mapa["lon"], errors="coerce")
mapa = mapa.dropna(subset=["lat", "lon"]).copy()

resp["_k"] = resp["nombre"].map(clave)
mapa["_k"] = mapa["nombre"].map(clave)
sin_mapa = set(resp["_k"]) - set(mapa["_k"])
if sin_mapa:
    print("AVISO: respuestas sin coordenadas en el mapa:", sorted(sin_mapa))
df = resp.merge(mapa[["_k", "instagram", "lat", "lon", "direccion"]], on="_k", how="left").drop(columns="_k")

# ---------------------------------------------------------------- limpieza de categorías
df["cerrado_segun_nombre"] = df["nombre"].str.contains("cerrado", case=False, na=False)
df["nombre_corto"] = df["nombre"].str.replace(r"\s*\(.*?\)", "", regex=True).str.strip()

for c in ("en_parkway", "vende_especialidad"):
    df[c] = df[c].str.replace("Si", "Sí", regex=False)

df["antiguedad"] = df["antiguedad"].replace({
    "De 1 menos de 3 años": "De 1 a menos de 3 años",
    "Menos de un año": "Menos de 1 año",
})
df["c2_proposito"] = df["c2_proposito"].replace({"No sabe no responde": "No sabe"})

ORDEN = {
    "c2_proposito": ["Del 0 al 25%", "Del 25 al 50%", "Del 50 al 75%", "Más de 75%", "No sabe"],
    "c5_permanencia": ["Menos de 30 minutos", "De 30-60 minutos", "De 1-2 horas", "Más de 2 horas"],
    "franjas": ["9-12pm", "12-2pm", "2-5pm", "5-8pm"],
    "antiguedad": ["Menos de 1 año", "De 1 a menos de 3 años", "De 3 a menos de 5 años", "5 años o más", "No sabe"],
}
PUNTO_MEDIO = {"Del 0 al 25%": 12.5, "Del 25 al 50%": 37.5, "Del 50 al 75%": 62.5, "Más de 75%": 87.5}
df["c2_punto_medio"] = df["c2_proposito"].map(PUNTO_MEDIO)
df["perm_orden"] = df["c5_permanencia"].map({v: i + 1 for i, v in enumerate(ORDEN["c5_permanencia"])})

# ---------------------------------------------------------------- casillas -> 0/1
METODOS = {
    "met_espresso": "Espresso", "met_leche": "Bebidas con leche", "met_v60": "V60",
    "met_chemex": "Chemex", "met_prensa": "Prensa francesa", "met_aeropress": "AeroPress",
    "met_frio": "Café frío",
}
for col, op in METODOS.items():
    df[col] = df["metodos"].map(lambda t: tiene(t, op))
df["n_metodos"] = df[list(METODOS)].sum(axis=1)
df["filtrados"] = df[["met_v60", "met_chemex", "met_prensa", "met_aeropress"]].max(axis=1)

CLIENTES = {
    "cli_estudiantes": "Estudiantes o profesores universitarios",
    "cli_salud": "Pacientes, acompañantes o personal de salud",
    "cli_oficinas": "Trabajadores de oficinas cercanas",
    "cli_vecinos": "Vecinos del barrio",
    "cli_proposito": "Personas de otras zonas que vienen a propósito",
    "cli_turistas": "Turistas",
}
for col, op in CLIENTES.items():
    df[col] = df["c1_clientes"].map(lambda t: tiene(t, op))
df["c1_n"] = df[list(CLIENTES)].sum(axis=1)

B2 = ["b2_univ", "b2_salud", "b2_ofic", "b2_tm", "b2_cafes", "b2_arriendo", "b2_calle"]
for c in B2:
    df[c] = pd.to_numeric(df[c], errors="coerce")

# ---------------------------------------------------------------- distancias entre cafeterías (medidas con las coordenadas)
d_min, n_cerca = [], []
for i, a in df.iterrows():
    ds = [haversine_m(a.lat, a.lon, b.lat, b.lon) for j, b in df.iterrows() if j != i]
    d_min.append(round(min(ds)))
    n_cerca.append(sum(1 for d in ds if d <= UMBRAL_M))
df["d_cafe_m"] = d_min
df["n_cafes_400"] = n_cerca
df["cerca_cafe"] = (df["n_cafes_400"] >= 1).astype(int)

# ---------------------------------------------------------------- distancias a equipamientos (opcional, se miden en el mapa)
ruta_d = RAW / "distancias_equipamientos.csv"
if ruta_d.exists():
    dist = pd.read_csv(ruta_d)
    dist["_k"] = dist["nombre"].map(clave)
    df["_k"] = df["nombre"].map(clave)
    df = df.merge(dist.drop(columns="nombre"), on="_k", how="left").drop(columns="_k")
    for tipo, col in (("univ", "d_univ_m"), ("salud", "d_salud_m"), ("ofic", "d_ofic_m"), ("TM", "d_TM_m")):
        df[f"cerca_{tipo}"] = (df[col] <= UMBRAL_M).astype("Int64").where(df[col].notna())
    print("Distancias a equipamientos incorporadas desde", ruta_d.name)
else:
    print("No hay data/raw/distancias_equipamientos.csv: se omiten las comparaciones por entorno.")

# ---------------------------------------------------------------- alertas de calidad
alertas = pd.DataFrame({"nombre": df["nombre"]})
alertas["cerrado_segun_nombre"] = df["cerrado_segun_nombre"]
alertas["c1_mas_de_3_opciones"] = df["c1_n"] > 3
alertas["c1_n_opciones"] = df["c1_n"]
alertas["b2_patron_repetido"] = df.duplicated(subset=B2, keep=False)
alertas["c2_sin_dato"] = df["c2_punto_medio"].isna()
alertas["antiguedad_no_sabe"] = df["antiguedad"].eq("No sabe")
alertas["origen_no_sabe"] = df["origen"].eq("No sabe")
alertas["llegada_no_sabe"] = df["c3_llegada"].eq("No sabe")
alertas["n_alertas"] = alertas.drop(columns=["nombre", "c1_n_opciones"]).sum(axis=1)

df = df.drop(columns=["metodos", "c1_clientes"])
df.to_csv(CLEAN / "cafes_tidy.csv", index=False, encoding="utf-8-sig")
alertas.to_csv(CLEAN / "calidad_datos.csv", index=False, encoding="utf-8-sig")
print(f"Listo: {len(df)} cafeterías en data/clean/cafes_tidy.csv")
print(f"Cafeterías con alguna alerta de calidad: {(alertas['n_alertas'] > 0).sum()} (ver data/clean/calidad_datos.csv)")
