# Diccionario de variables (`data/clean/cafes_tidy.csv`)

Una fila por cafetería. Todas las respuestas son estimaciones del encargado, salvo las columnas calculadas con el mapa.

| Variable | Qué es | Valores |
| --- | --- | --- |
| `nombre`, `nombre_corto` | Nombre del negocio (completo y sin paréntesis) | Texto |
| `lat`, `lon`, `direccion`, `instagram` | Ubicación y redes, del archivo del mapa | Número y texto |
| `cerrado_segun_nombre` | El mapa lo marca como cerrado | Verdadero o falso |
| `en_parkway`, `acepta`, `mayor18`, `vende_especialidad` | Preguntas de filtro | Sí o No |
| `antiguedad` | Hace cuánto funciona el local en esa dirección | Menos de 1 año, De 1 a menos de 3 años, De 3 a menos de 5 años, 5 años o más, No sabe |
| `local_tipo` | El local es propio o arrendado | Propio, Arrendado |
| `tuesta` | Tuestan su propio café | Sí, No (compran tostado), No sabe |
| `met_espresso`, `met_leche`, `met_v60`, `met_chemex`, `met_prensa`, `met_aeropress`, `met_frio` | Método de preparación que ofrecen | 1 o 0 |
| `n_metodos`, `filtrados` | Número de métodos, y si ofrece alguno filtrado (V60, Chemex, prensa francesa o AeroPress) | Número, 1 o 0 |
| `origen` | El café tiene origen identificable | Sí siempre, Sí algunas veces, No, No sabe |
| `b2_univ`, `b2_salud`, `b2_ofic`, `b2_tm`, `b2_cafes`, `b2_arriendo`, `b2_calle` | Importancia del factor al escoger el lugar | 1 (nada importante) a 5 (muy importante) |
| `b3_percepcion` | Tener otras cafeterías cerca es… | Muy negativo a Muy positivo |
| `b4_otras_zonas`, `b4_cuales` | Consideraron otras zonas, y cuáles | Sí o No, texto |
| `cli_estudiantes`, `cli_salud`, `cli_oficinas`, `cli_vecinos`, `cli_proposito`, `cli_turistas` | Tipos de cliente más frecuentes | 1 o 0 |
| `c1_n` | Cuántos tipos de cliente marcó (el formulario pedía hasta 3) | Número |
| `c2_proposito`, `c2_punto_medio` | Parte de clientes que viene de fuera del barrio a propósito, y el punto medio del intervalo | Intervalo, 12,5 a 87,5 |
| `c3_llegada` | Cómo llega la mayoría de clientes | A pie, Carro o moto, TransMilenio o SITP, Bicicleta, No sabe |
| `c4_semana`, `c4_finde` | Franja de más clientes entre semana y en fin de semana | 9-12pm, 12-2pm, 2-5pm, 5-8pm |
| `c5_permanencia`, `perm_orden` | Tiempo que se queda un cliente, y su orden de 1 a 4 | Menos de 30 minutos a Más de 2 horas |
| `d_cafe_m` | Distancia en metros a la otra cafetería de la lista más cercana | Número (calculado con las coordenadas) |
| `n_cafes_400`, `cerca_cafe` | Otras cafeterías de la lista a 400 m o menos, y si hay al menos una | Número, 1 o 0 |
| `d_univ_m`, `d_salud_m`, `d_ofic_m`, `d_TM_m` | Distancia medida en el mapa al equipamiento más cercano (solo si existe `distancias_equipamientos.csv`) | Metros |
| `cerca_univ`, `cerca_salud`, `cerca_ofic`, `cerca_TM` | 1 si la distancia es de 400 m o menos | 1 o 0 |
