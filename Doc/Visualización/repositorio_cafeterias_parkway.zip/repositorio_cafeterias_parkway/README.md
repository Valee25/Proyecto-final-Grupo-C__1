# Cafeterías de especialidad en el área del Park Way (Bogotá)

Trabajo final de Haciendo Economía 2026-2. Este repositorio contiene los datos de la encuesta a encargados de cafeterías, los scripts que los limpian y las visualizaciones. Cualquier persona puede reproducir todo con los pasos de abajo.

## Cómo reproducirlo

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate      Mac o Linux: source .venv/bin/activate
pip install -r requirements.txt
python scripts/01_limpiar.py     # lee data/raw y escribe data/clean
python scripts/02_graficas.py    # escribe outputs/figuras y outputs/tablas
```

## Estructura

| Carpeta | Contenido |
| --- | --- |
| `data/raw` | Datos originales, sin tocar: `Respuestas_encuesta.xlsx` (exportación de Google Forms) y `Mapa_cafes.xlsx` (nombre, dirección y coordenadas de cada local) |
| `data/clean` | `cafes_tidy.csv` (una fila por cafetería, variables codificadas) y `calidad_datos.csv` (alertas de calidad) |
| `scripts` | `01_limpiar.py` y `02_graficas.py` |
| `outputs/figuras` | Las visualizaciones en PNG |
| `outputs/tablas` | Los conteos que muestra cada figura, en CSV |
| `docs` | `diccionario_variables.md` |

## Qué muestra cada figura

| Figura | Qué muestra | Hipótesis |
| --- | --- | --- |
| `fig01_mapa_cafeterias` | Ubicación de las 16 cafeterías, coloreadas por la parte de clientes que viene a propósito | Contexto |
| `fig02_importancia_factores` | Importancia declarada de cada factor al escoger el lugar | Contexto |
| `fig03_clientela` | Tipos de clientes frecuentes | H1 |
| `fig04_a_proposito` | Parte de clientes que viene de fuera del barrio a propósito | H2, H3 |
| `fig05_llegada` | Cómo llegan los clientes | H2 |
| `fig06_horarios` | Franja de mayor afluencia entre semana y en fin de semana | H2, H4 |
| `fig07_permanencia` | Tiempo que se queda un cliente | H1, H4 |
| `fig08_aglomeracion` | Otras cafeterías a 400 m frente a clientes que llegan a propósito | H3 |
| `fig09_estudiantes_permanencia` | Permanencia según si el local menciona a estudiantes entre sus clientes | H1 (aproximación) |
| `fig10_metodos` | Métodos de preparación que ofrecen | Descriptiva |
| `fig11_*` | Comparaciones "cerca frente a lejos" por entorno | H1, H2 y H4. **Solo aparecen cuando exista `data/raw/distancias_equipamientos.csv`** |

## Lo que falta para completar H1, H2 y H4

Las hipótesis comparan cafeterías según qué tan cerca están de universidades, clínicas y hospitales, oficinas y estaciones de TransMilenio. Esas distancias se miden en el mapa y todavía no están en los datos. Para incorporarlas:

1. Copien `data/raw/distancias_equipamientos_plantilla.csv` como `data/raw/distancias_equipamientos.csv`.
2. Llenen una fila por cafetería con el mismo nombre que en `Respuestas_encuesta.xlsx` y las cuatro distancias en metros.
3. Vuelvan a correr los dos scripts. Aparecerán las figuras `fig11_*`.

La distancia entre cafeterías (`d_cafe_m`, `n_cafes_400`) sí está calculada con las coordenadas del mapa. Se considera "cerca" una distancia de 400 m o menos (`UMBRAL_M` en los scripts). Una comparación solo se hace si cada grupo tiene al menos 4 cafeterías (`MIN_GRUPO`).

## Datos: qué son y cómo leerlos

- **Son 16 respuestas**, una por cafetería, de la encuesta que se aplicó a encargados con Google Forms. Con tan pocos locales, todo es descriptivo y exploratorio. No permite hablar de causas.
- **Casi todas las variables son estimaciones del encargado** (clientela, parte que viene a propósito, cómo llegan, franja de más clientes y permanencia). No son observación directa. La ficha de observación no está en esta versión de los datos.
- **No hay datos personales.** Solo el nombre del negocio.

## Alertas de calidad de los datos

El script `01_limpiar.py` las marca en `data/clean/calidad_datos.csv`. Hay que decirlas en el informe y revisarlas antes de sacar conclusiones:

- **Doppio Café** aparece con el nombre "Cerrado permanentemente" en el mapa y tiene una respuesta. Para dejarla fuera, cambien `EXCLUIR_CERRADOS = True` en `02_graficas.py`.
- **Nueve cafeterías marcaron más de tres tipos de cliente**, aunque el formulario pedía hasta tres. Las figuras de clientela cuentan todas las opciones marcadas.
- **Bizcotela y La cesta tienen exactamente las mismas calificaciones** en la importancia de los siete factores. Conviene confirmar que no sea un error de registro.
- **Los intervalos de "parte que viene a propósito" se solapan** en 25 %, 50 % y 75 % ("Del 0 al 25 %", "Del 25 al 50 %", etc.). Las figuras usan el punto medio de cada intervalo.
- Hay respuestas "No sabe" en antigüedad (1), en cómo llegan los clientes (2) y en la parte que viene a propósito (1). Se conservan como categoría y no se completan.

## Lectura rápida (con los 16 locales de esta versión)

- Todas ofrecen espresso. Después vienen las bebidas con leche (13), la prensa francesa (9), el café frío (8), el V60 (7), el Chemex (5) y el AeroPress (4).
- Los clientes más mencionados son trabajadores de oficinas (14 de 16), vecinos (13) y personas que vienen a propósito (12). Los estudiantes o profesores se mencionan en 6.
- La permanencia más frecuente es de 30 a 60 minutos (9 de 16).
- Los encargados dicen que lo que más pesó al escoger el lugar fue el ambiente de la calle (media 4,4) y la cercanía a oficinas (4,1). La cercanía a universidades pesó menos (2,4).
- Entre semana la franja más señalada es de 14:00 a 17:00 (6 cafeterías), y en fin de semana de 17:00 a 20:00 (7).
- Más cafeterías cerca no se asocia con más clientes que llegan a propósito (Spearman, rho = -0,10, p = 0,73, n = 15). Es exploratorio y con muy pocos locales.
