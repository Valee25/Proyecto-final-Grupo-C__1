"""Ejecuta todo el proceso: limpieza de datos y generación de las 9 figuras.

Uso (desde la carpeta del repositorio):
    python codigo/ejecutar_todo.py
"""
import subprocess
import sys
from pathlib import Path

CODIGO = Path(__file__).resolve().parent
for script in ('01_limpiar_datos.py', '02_figuras.py'):
    print(f'>>> {script}')
    subprocess.run([sys.executable, str(CODIGO / script)], check=True)
print('Proceso completo. Revisa las carpetas datos/clean y figuras.')
