"""
Paso 1 · Limpieza de datos
==========================
Lee los dos archivos originales (datos/raw) y crea dos tablas limpias (datos/clean):

    locales_limpio.csv   una fila por local (16): ubicación, zona (Dentro/Fuera) y estado de la visita
    encuesta_limpia.csv  una fila por local con respuesta válida (15): respuestas ya codificadas

Reglas de limpieza (todas visibles en este archivo):
  * La zona sale de la columna "¿Dentro del Park Way?" del mapa final (Si = Dentro, No = Fuera).
    Se verifica que coincida con la respuesta de la encuesta a "¿El establecimiento se encuentra en el Park way?".
  * Doppio Café figura como "cerrado permanentemente": se conserva en locales_limpio.csv para
    trazabilidad, pero no tiene respuestas y queda fuera de encuesta_limpia.csv (15 locales válidos).
  * Las preguntas de opción múltiple (clientes, métodos) se convierten en columnas 0/1.
  * "Otras cafeterías a 400 m o menos" se calcula con las coordenadas del mapa, contando solo
    los otros locales válidos (se excluye a Doppio Café).

Uso:  python codigo/01_limpiar_datos.py
"""
import math
import re
from pathlib import Path

import openpyxl
import pandas as pd

RAIZ = Path(__file__).resolve().parent.parent
RAW = RAIZ / 'datos' / 'raw'
CLEAN = RAIZ / 'datos' / 'clean'
CLEAN.mkdir(parents=True, exist_ok=True)

RADIO_AGLOMERACION_M = 400


# ------------------------------------------------------------------ utilidades
def distancia_m(lat1, lon1, lat2, lon2):
    """Distancia en línea recta (haversine), en metros."""
    r = 6371000
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dphi, dlmb = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dphi / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlmb / 2) ** 2
    return 2 * r * math.asin(math.sqrt(a))


def texto_a_metros(texto):
    """'80 mts desde el parkway' -> 80 ; '1km desde el Park Way' -> 1000 ; 'N/A' -> NaN."""
    if texto is None:
        return float('nan')
    m = re.search(r'(\d+(?:[.,]\d+)?)\s*(km|mts|m)\b', str(texto).lower())
    if not m:
        return float('nan')
    valor = float(m.group(1).replace(',', '.'))
    return valor * 1000 if m.group(2) == 'km' else valor


# ------------------------------------------------------------------ 1. mapa -> locales
ws = openpyxl.load_workbook(RAW / 'MapaCafes_Final.xlsx', data_only=True).active
filas = []
for r in ws.iter_rows(min_row=2, values_only=True):
    if r[0] is None or str(r[0]).startswith('Mapa'):
        break
    filas.append(r[:7])
locales = pd.DataFrame(filas, columns=['nombre_original', 'instagram', 'latitud', 'longitud',
                                       'distancia_texto', 'direccion', 'dentro_respuesta'])
locales['latitud'] = locales['latitud'].astype(float)
locales['longitud'] = locales['longitud'].astype(float)
locales['nombre'] = locales['nombre_original'].str.replace(r'\s*\(.*\)\s*$', '', regex=True).str.strip()
locales['estado'] = locales['nombre_original'].apply(
    lambda s: 'Cerrado permanentemente' if 'Cerrado' in s else 'Respondió')
locales['zona'] = locales['dentro_respuesta'].map({'Si': 'Dentro', 'No': 'Fuera'})
locales['distancia_m_aprox'] = locales['distancia_texto'].apply(texto_a_metros)
locales.insert(0, 'id', [f'CAF{i:02d}' for i in range(1, len(locales) + 1)])
locales['incluido_en_analisis'] = (locales['estado'] == 'Respondió').astype(int)

# ------------------------------------------------------------------ 2. encuesta
ENC = RAW / 'Respuestas_encuesta_final.xlsx'
bruto = pd.read_excel(ENC)
assert bruto.shape[1] == 26, f'Se esperaban 26 columnas y hay {bruto.shape[1]}'
cabeceras = list(bruto.columns)
nombres_importancia = [re.search(r'\[(.*?)\]\s*$', c).group(1).strip() for c in cabeceras[10:17]]
bruto.columns = (['nombre', 'en_parkway_respuesta', 'consentimiento', 'mayor_edad', 'vende_especialidad',
                  'antiguedad', 'tipo_local', 'tuesta', 'metodos', 'origen']
                 + [f'imp_{n}' for n in nombres_importancia]
                 + ['otras_cerca_es', 'considero_otras_zonas', 'zona_considerada', 'clientes',
                    'a_proposito', 'llegada', 'franja_semana', 'franja_finde', 'permanencia'])
bruto['nombre'] = bruto['nombre'].astype(str).str.replace(r'\s*\(.*\)\s*$', '', regex=True).str.strip()
bruto = bruto.drop_duplicates(subset='nombre')

valida = bruto[bruto['nombre'].isin(locales.loc[locales['incluido_en_analisis'] == 1, 'nombre'])].copy()
valida = valida.merge(locales[['id', 'nombre', 'zona']], on='nombre', how='left', validate='one_to_one')

# Controles de consistencia
assert valida['zona'].notna().all(), 'Hay locales de la encuesta que no están en el mapa'
coincide = valida['en_parkway_respuesta'].map({'Si': 'Dentro', 'No': 'Fuera'}) == valida['zona']
assert coincide.all(), f"Zona del mapa y de la encuesta no coinciden en: {list(valida.loc[~coincide, 'nombre'])}"

# Opción múltiple -> 0/1
CLIENTES = {'cliente_estudiantes': 'Estudiantes o profesores universitarios',
            'cliente_salud': 'Pacientes, acompañantes o personal de salud',
            'cliente_oficinas': 'Trabajadores de oficinas cercanas',
            'cliente_vecinos': 'Vecinos del barrio',
            'cliente_proposito': 'Personas de otras zonas que vienen a propósito a la cafetería',
            'cliente_turistas': 'Turistas'}
for col, etiqueta in CLIENTES.items():
    valida[col] = valida['clientes'].fillna('').str.contains(etiqueta, regex=False).astype(int)
valida['n_tipos_cliente'] = valida[list(CLIENTES)].sum(axis=1)

METODOS = {'metodo_espresso': 'Espresso', 'metodo_leche': 'Bebidas con leche', 'metodo_v60': 'V60',
           'metodo_chemex': 'Chemex', 'metodo_prensa': 'Prensa francesa', 'metodo_aeropress': 'AeroPress',
           'metodo_frio': 'Café frío'}
for col, etiqueta in METODOS.items():
    valida[col] = valida['metodos'].fillna('').str.contains(etiqueta, regex=False).astype(int)

valida['tuesta_propio'] = valida['tuesta'].fillna('').str.startswith('Sí').astype(int)
PUNTO_MEDIO = {'Del 0 al 25%': 12.5, 'Del 25 al 50%': 37.5, 'Del 50 al 75%': 62.5, 'Más de 75%': 87.5}
valida['a_proposito_punto_medio'] = valida['a_proposito'].map(PUNTO_MEDIO)
for n in nombres_importancia:
    valida[f'imp_{n}'] = pd.to_numeric(valida[f'imp_{n}'])

# Aglomeración: otros locales válidos a RADIO_AGLOMERACION_M o menos
pts = locales[locales['incluido_en_analisis'] == 1].set_index('nombre')[['latitud', 'longitud']]
valida['otras_en_400m'] = valida['nombre'].apply(
    lambda n: sum(1 for m, q in pts.iterrows()
                  if m != n and distancia_m(pts.loc[n, 'latitud'], pts.loc[n, 'longitud'],
                                            q['latitud'], q['longitud']) <= RADIO_AGLOMERACION_M))

# ------------------------------------------------------------------ 3. guardar
locales.drop(columns=['nombre_original', 'dentro_respuesta']).to_csv(CLEAN / 'locales_limpio.csv', index=False, encoding='utf-8-sig')
orden = ['id', 'nombre', 'zona'] + [c for c in valida.columns if c not in ('id', 'nombre', 'zona')]
valida[orden].to_csv(CLEAN / 'encuesta_limpia.csv', index=False, encoding='utf-8-sig')

n_in = int((valida['zona'] == 'Dentro').sum())
n_out = int((valida['zona'] == 'Fuera').sum())
print(f'Locales en el mapa: {len(locales)} | válidos: {len(valida)} (dentro {n_in}, fuera {n_out}) | '
      f'excluidos: {list(locales.loc[locales["incluido_en_analisis"] == 0, "nombre"])}')
print(f'Archivos escritos en {CLEAN}')
