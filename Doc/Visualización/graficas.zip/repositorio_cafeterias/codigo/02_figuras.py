"""
Paso 2 · Figuras
================
Lee datos/clean/encuesta_limpia.csv y crea las 9 figuras del proyecto en figuras/ (PNG)
y un PDF con las 9 páginas (figuras/figuras_cafeterias.pdf).

Convenciones (iguales en todas las figuras):
  * VERDE = local dentro del Park Way · ROJO = local fuera del Park Way (como en el mapa final).
  * Siempre aparecen las dos zonas, con su n en la leyenda.
  * Como el rojo y el verde se confunden con algunas formas de daltonismo, "Fuera" lleva además
    rayado en las barras y rombo en los puntos, y cada barra lleva su conteo ("k de n").
  * Todas las medidas son estimaciones declaradas por el encargado del local, no mediciones.

Uso:  python codigo/02_figuras.py
"""
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

RAIZ = Path(__file__).resolve().parent.parent
SALIDA = RAIZ / 'figuras'
SALIDA.mkdir(exist_ok=True)

VERDE, ROJO = '#2e9e5b', '#c4321f'
INK, INK2, GRID = '#111111', '#555555', '#e4e2de'
plt.rcParams.update({'font.family': 'DejaVu Sans', 'text.color': INK, 'axes.labelcolor': INK2,
                     'xtick.color': INK2, 'ytick.color': INK2, 'axes.edgecolor': GRID,
                     'hatch.linewidth': 1.2})

df = pd.read_csv(RAIZ / 'datos' / 'clean' / 'encuesta_limpia.csv')
dentro, fuera = df[df['zona'] == 'Dentro'], df[df['zona'] == 'Fuera']
N_IN, N_OUT = len(dentro), len(fuera)
LBL_IN, LBL_OUT = f'Dentro del Park Way (n = {N_IN})', f'Fuera del Park Way (n = {N_OUT})'
FUENTE = f'Fuente: encuesta a encargados de {len(df)} cafeterías de especialidad, noviembre de 2026. '
ESTIMA = 'Son estimaciones del personal, no mediciones.'


# ------------------------------------------------------------------ piezas comunes
def leyenda_zonas(ax, loc='lower right'):
    ax.legend(handles=[Patch(facecolor=VERDE, edgecolor='white', label=LBL_IN),
                       Patch(facecolor=ROJO, edgecolor='white', hatch='///', label=LBL_OUT)],
              loc=loc, frameon=False, fontsize=8.5)


def limpiar_ejes(ax, grilla='x'):
    for s in ('top', 'right', 'left' if grilla == 'x' else 'bottom'):
        ax.spines[s].set_visible(False)
    ax.tick_params(length=0)
    getattr(ax, f'{grilla}axis').grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)


def encabezado(fig, titulo, subtitulo, pie):
    fig.suptitle(titulo, x=0.012, y=0.985, ha='left', fontsize=12.5, fontweight='bold', color=INK)
    fig.text(0.012, 0.925, subtitulo, ha='left', fontsize=9, color=INK2)
    fig.text(0.012, 0.012, pie, ha='left', fontsize=7.3, color=INK2, wrap=True)


def barras_zonas(ax, etiquetas, k_in, k_out, n_in=N_IN, n_out=N_OUT):
    """Barras horizontales agrupadas (porcentaje de locales de cada zona) con 'k de n'."""
    h = 0.36
    for i, (k1, k2) in enumerate(zip(k_in, k_out)):
        y = len(etiquetas) - 1 - i
        for desp, k, n, color, hatch in ((+h / 2 + 0.01, k1, n_in, VERDE, None), (-h / 2 - 0.01, k2, n_out, ROJO, '///')):
            pct = 100 * k / n
            ax.barh(y + desp, pct, height=h, color=color, edgecolor='white', linewidth=1, hatch=hatch)
            ax.text(pct + 1.5, y + desp, f'{k} de {n}', va='center', fontsize=8.5, color=INK2)
    ax.set_yticks(range(len(etiquetas)))
    ax.set_yticklabels(etiquetas[::-1], fontsize=9.5, color=INK)
    ax.set_xlim(0, 115)
    ax.set_xticks([0, 25, 50, 75, 100])
    ax.set_xticklabels(['0 %', '25 %', '50 %', '75 %', '100 %'], fontsize=8.5)
    ax.set_xlabel('Porcentaje de locales de cada zona', fontsize=9)
    limpiar_ejes(ax, 'x')


def conteo(grupo, columna, categoria):
    return int((grupo[columna] == categoria).sum())


def figura_barras(titulo, subtitulo, etiquetas, k_in, k_out, pie):
    fig, ax = plt.subplots(figsize=(8.4, 0.66 * len(etiquetas) + 2.6), dpi=200)
    barras_zonas(ax, etiquetas, k_in, k_out)
    leyenda_zonas(ax)
    encabezado(fig, titulo, subtitulo, pie)
    fig.tight_layout(rect=(0, 0.05, 1, 0.9))
    return fig


# ------------------------------------------------------------------ Figura 1: importancia de factores
def fig1():
    cols = [c for c in df.columns if c.startswith('imp_')]
    orden = sorted(cols, key=lambda c: -df[c].mean())
    fig, ax = plt.subplots(figsize=(8.4, 5.6), dpi=200)
    h = 0.36
    for i, c in enumerate(orden):
        y = len(orden) - 1 - i
        for desp, g, color, hatch in ((+h / 2 + 0.01, dentro, VERDE, None), (-h / 2 - 0.01, fuera, ROJO, '///')):
            m = g[c].mean()
            ax.barh(y + desp, m, height=h, color=color, edgecolor='white', linewidth=1, hatch=hatch)
            ax.text(m + 0.06, y + desp, f'{m:.1f}', va='center', fontsize=8.5, color=INK2)
    ax.set_yticks(range(len(orden)))
    ax.set_yticklabels([c.replace('imp_', '') for c in orden][::-1], fontsize=9.5, color=INK)
    ax.set_xlim(0, 5.6)
    ax.set_xticks([1, 2, 3, 4, 5])
    ax.set_xlabel('Importancia media declarada (1 = nada importante, 5 = muy importante)', fontsize=9)
    limpiar_ejes(ax, 'x')
    leyenda_zonas(ax)
    encabezado(fig, 'Figura 1 · Qué tan importante fue cada factor al escoger el lugar',
               'Promedio de las respuestas de los encargados, por zona (factores ordenados de mayor a menor promedio general)',
               FUENTE + 'Razón declarada por el encargado, no medida del entorno. Con 6 y 9 locales, los promedios son descriptivos.')
    fig.tight_layout(rect=(0, 0.05, 1, 0.9))
    return fig


# ------------------------------------------------------------------ Figura 2: clientela
def fig2():
    tipos = [('cliente_oficinas', 'Trabajadores de oficinas cercanas'), ('cliente_vecinos', 'Vecinos del barrio'),
             ('cliente_proposito', 'Personas de otras zonas, a propósito'), ('cliente_turistas', 'Turistas'),
             ('cliente_salud', 'Pacientes, acompañantes o personal de salud'),
             ('cliente_estudiantes', 'Estudiantes o profesores universitarios')]
    return figura_barras('Figura 2 · Clientela frecuente según el encargado',
                         'Porcentaje de locales de cada zona que mencionan cada tipo de cliente (podían marcar varios)',
                         [t[1] for t in tipos], [int(dentro[t[0]].sum()) for t in tipos], [int(fuera[t[0]].sum()) for t in tipos],
                         FUENTE + f'El formulario pedía hasta tres opciones: {int((df["n_tipos_cliente"] > 3).sum())} locales marcaron más. ' + ESTIMA)


# ------------------------------------------------------------------ Figura 3: a propósito
def fig3():
    cats = ['Del 0 al 25%', 'Del 25 al 50%', 'Del 50 al 75%', 'Más de 75%', 'No sabe no responde']
    etiquetas = ['0 a 25 %', '25 a 50 %', '50 a 75 %', 'Más de 75 %', 'No sabe / no responde']
    return figura_barras('Figura 3 · Parte de los clientes que viene a propósito desde fuera del barrio',
                         'Porcentaje de locales de cada zona según el rango que indica el encargado',
                         etiquetas, [conteo(dentro, 'a_proposito', c) for c in cats], [conteo(fuera, 'a_proposito', c) for c in cats],
                         FUENTE + 'Los rangos del formulario se solapan en 25 %, 50 % y 75 %. ' + ESTIMA)


# ------------------------------------------------------------------ Figura 4: cómo llegan
def fig4():
    cats = ['A pie', 'Carro o moto', 'TransMilenio o SITP', 'Bicicleta', 'No sabe']
    return figura_barras('Figura 4 · Cómo llega la mayoría de los clientes',
                         'Porcentaje de locales de cada zona según el medio que señala el encargado (una opción)',
                         cats, [conteo(dentro, 'llegada', c) for c in cats], [conteo(fuera, 'llegada', c) for c in cats],
                         FUENTE + ESTIMA)


# ------------------------------------------------------------------ Figura 5: franja horaria
def fig5():
    cats = ['9-12pm', '12-2pm', '2-5pm', '5-8pm']
    etiquetas = ['9:00 a 12:00', '12:00 a 14:00', '14:00 a 17:00', '17:00 a 20:00']
    fig, axes = plt.subplots(1, 2, figsize=(9.6, 4.9), dpi=200, sharey=True)
    w = 0.38
    for ax, col, titulo in ((axes[0], 'franja_semana', 'Entre semana'), (axes[1], 'franja_finde', 'Fin de semana')):
        x = np.arange(len(cats))
        for desp, g, n, color, hatch in ((-w / 2 - 0.01, dentro, N_IN, VERDE, None), (+w / 2 + 0.01, fuera, N_OUT, ROJO, '///')):
            ks = [conteo(g, col, c) for c in cats]
            ax.bar(x + desp, [100 * k / n for k in ks], width=w, color=color, edgecolor='white', linewidth=1, hatch=hatch)
            for xi, k in zip(x + desp, ks):
                ax.text(xi, 100 * k / n + 1.5, f'{k} de {n}', ha='center', va='bottom', fontsize=7.6, color=INK2)
        ax.set_xticks(x)
        ax.set_xticklabels(etiquetas, fontsize=8.5)
        ax.set_ylim(0, 112)
        ax.set_yticks([0, 25, 50, 75, 100])
        ax.set_yticklabels(['0 %', '25 %', '50 %', '75 %', '100 %'], fontsize=8.5)
        ax.set_title(titulo, loc='left', fontsize=10.5, fontweight='bold', color=INK)
        limpiar_ejes(ax, 'y')
    axes[0].set_ylabel('Porcentaje de locales de cada zona', fontsize=9)
    leyenda_zonas(axes[0], loc='upper left')
    encabezado(fig, 'Figura 5 · Franja de mayor afluencia declarada',
               'Porcentaje de locales de cada zona según la franja horaria más frecuente que señala el encargado',
               FUENTE + 'Ningún local señaló 6:00 a 9:00 ni después de las 20:00. ' + ESTIMA)
    fig.tight_layout(rect=(0, 0.05, 1, 0.9))
    return fig


# ------------------------------------------------------------------ Figura 6: permanencia
ORDEN_PERM = ['Menos de 30 minutos', 'De 30-60 minutos', 'De 1-2 horas', 'Más de 2 horas']


def fig6():
    return figura_barras('Figura 6 · Tiempo que se queda un cliente en el local',
                         'Porcentaje de locales de cada zona según la permanencia típica que señala el encargado',
                         ['Menos de 30 minutos', '30 a 60 minutos', '1 a 2 horas', 'Más de 2 horas'],
                         [conteo(dentro, 'permanencia', c) for c in ORDEN_PERM], [conteo(fuera, 'permanencia', c) for c in ORDEN_PERM],
                         FUENTE + 'Es una estimación del encargado, no una observación.')


# ------------------------------------------------------------------ Figura 7: aglomeración
def fig7():
    d = df.dropna(subset=['a_proposito_punto_medio'])
    fig, ax = plt.subplots(figsize=(8.4, 5.6), dpi=200)
    rng = np.random.default_rng(7)  # desplazamiento fijo para que se vean los puntos superpuestos
    for g, color, marker, lbl in ((d[d['zona'] == 'Dentro'], VERDE, 'o', LBL_IN), (d[d['zona'] == 'Fuera'], ROJO, 'D', LBL_OUT)):
        ax.scatter(g['otras_en_400m'] + rng.uniform(-0.18, 0.18, len(g)), g['a_proposito_punto_medio'] + rng.uniform(-1.8, 1.8, len(g)),
                   s=95, color=color, marker=marker, edgecolor='white', linewidth=1.3, label=lbl, zorder=3)
    ax.set_xlabel('Otras cafeterías de la lista a 400 m o menos', fontsize=9)
    ax.set_ylabel('Clientes que vienen a propósito (punto medio del rango, %)', fontsize=9)
    ax.set_xlim(-0.8, 12.2)
    ax.set_ylim(0, 100)
    ax.set_xticks(range(0, 13, 2))
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    ax.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.legend(loc='upper left', frameon=False, fontsize=8.5)
    encabezado(fig, 'Figura 7 · Aglomeración y clientela que llega a propósito',
               f'Cada punto es un local ({len(d)} con dato); el color indica la zona. Gráfica exploratoria, sin prueba estadística',
               FUENTE + 'Las cafeterías cercanas se cuentan solo dentro de la lista. Se excluye un local que no supo responder. '
                        'Puntos desplazados levemente para verlos. ' + ESTIMA)
    fig.tight_layout(rect=(0, 0.06, 1, 0.9))
    return fig


# ------------------------------------------------------------------ Figura 8: permanencia y clientela universitaria
def fig8():
    nivel = {c: i for i, c in enumerate(ORDEN_PERM)}
    d = df.assign(y=df['permanencia'].map(nivel))
    grupos = [(0, d[d['cliente_estudiantes'] == 0], 'No los menciona'), (1, d[d['cliente_estudiantes'] == 1], 'Los menciona')]
    fig, ax = plt.subplots(figsize=(8.4, 5.4), dpi=200)
    rng = np.random.default_rng(11)
    for x0, g, _ in grupos:
        for zona, color, marker in (('Dentro', VERDE, 'o'), ('Fuera', ROJO, 'D')):
            s = g[g['zona'] == zona]
            ax.scatter(x0 + rng.uniform(-0.22, 0.22, len(s)), s['y'] + rng.uniform(-0.07, 0.07, len(s)),
                       s=95, color=color, marker=marker, edgecolor='white', linewidth=1.3, zorder=3)
        ax.hlines(g['y'].median(), x0 - 0.3, x0 + 0.3, color=INK, linewidth=2, zorder=2)
    ax.set_xticks([0, 1])
    ax.set_xticklabels([f'No los menciona\n(n = {len(grupos[0][1])})', f'Los menciona\n(n = {len(grupos[1][1])})'], fontsize=9.5, color=INK)
    ax.set_yticks(range(4))
    ax.set_yticklabels(['Menos de 30 min', '30 a 60 min', '1 a 2 horas', 'Más de 2 horas'], fontsize=9.5, color=INK)
    ax.set_xlim(-0.6, 1.6)
    ax.set_ylim(-0.5, 3.5)
    ax.set_xlabel('¿Menciona a estudiantes o profesores entre sus clientes frecuentes?', fontsize=9)
    for s in ('top', 'right'):
        ax.spines[s].set_visible(False)
    ax.tick_params(length=0)
    ax.yaxis.grid(True, color=GRID, linewidth=0.8)
    ax.set_axisbelow(True)
    ax.legend(handles=[Line2D([0], [0], marker='o', color='w', markerfacecolor=VERDE, markersize=9, label=LBL_IN),
                       Line2D([0], [0], marker='D', color='w', markerfacecolor=ROJO, markersize=8, label=LBL_OUT),
                       Line2D([0], [0], color=INK, linewidth=2, label='Mediana del grupo')],
              loc='upper center', frameon=False, fontsize=8.5, ncol=3, bbox_to_anchor=(0.5, 1.02))
    encabezado(fig, 'Figura 8 · Permanencia declarada según la clientela universitaria',
               'Cada punto es un local; el color indica la zona. La raya negra es la mediana de cada grupo',
               FUENTE + 'Puntos desplazados levemente para verlos. ' + ESTIMA)
    fig.tight_layout(rect=(0, 0.05, 1, 0.9))
    return fig


# ------------------------------------------------------------------ Figura 9: métodos
def fig9():
    m = [('metodo_espresso', 'Espresso'), ('metodo_leche', 'Bebidas con leche'), ('metodo_prensa', 'Prensa francesa'),
         ('metodo_frio', 'Café frío'), ('metodo_v60', 'V60'), ('metodo_chemex', 'Chemex'), ('metodo_aeropress', 'AeroPress')]
    return figura_barras('Figura 9 · Métodos de preparación que ofrecen',
                         'Porcentaje de locales de cada zona que ofrecen cada método (podían marcar varios)',
                         [x[1] for x in m], [int(dentro[x[0]].sum()) for x in m], [int(fuera[x[0]].sum()) for x in m],
                         FUENTE + 'Respuesta del encargado.')


FIGURAS = [('fig1_importancia_factores', fig1), ('fig2_clientela_frecuente', fig2), ('fig3_clientes_a_proposito', fig3),
           ('fig4_como_llegan', fig4), ('fig5_franja_afluencia', fig5), ('fig6_permanencia', fig6),
           ('fig7_aglomeracion_a_proposito', fig7), ('fig8_permanencia_universitarios', fig8), ('fig9_metodos_preparacion', fig9)]

with PdfPages(SALIDA / 'figuras_cafeterias.pdf') as pdf:
    for nombre, f in FIGURAS:
        fig = f()
        fig.savefig(SALIDA / f'{nombre}.png', facecolor='white')
        pdf.savefig(fig, facecolor='white')
        plt.close(fig)
        print('  ', nombre)
print(f'Listo: {len(FIGURAS)} figuras en {SALIDA} (dentro = {N_IN} locales, fuera = {N_OUT})')
