# Cafeterías de especialidad dentro y fuera del Park Way (Bogotá)

Repositorio del Paso 5 (visualizaciones) · Haciendo Economía 2026-2 · Grupo C.

**Pregunta:** ¿en qué se diferencian las cafeterías de especialidad dentro del corredor del Park Way de las que están
fuera de él, en su clientela, sus horarios de mayor afluencia y el tiempo que se quedan los clientes?

Todas las figuras comparan las dos zonas: **verde = dentro del Park Way** y **rojo = fuera** (el mismo criterio del mapa final).

## Cómo replicar

1. Instalar Python 3.10 o superior.
2. En la carpeta del repositorio: `pip install -r requirements.txt`
3. Ejecutar: `python codigo/ejecutar_todo.py`

Eso limpia los datos y vuelve a crear las 9 figuras en `figuras/`. También se pueden correr por separado
`codigo/01_limpiar_datos.py` y `codigo/02_figuras.py`. Los scripts usan rutas relativas, así que funcionan desde
cualquier carpeta donde se descomprima el repositorio.

## Estructura

| Carpeta o archivo | Contenido |
|---|---|
| `datos/raw/MapaCafes_Final.xlsx` | Lista de locales con coordenadas, dirección y la columna "¿Dentro del Park Way?" (original) |
| `datos/raw/Respuestas_encuesta_final.xlsx` | Respuestas del cuestionario a los encargados (original, sin modificar) |
| `datos/clean/locales_limpio.csv` | 16 locales: zona (Dentro/Fuera) y estado de la visita |
| `datos/clean/encuesta_limpia.csv` | 15 locales con respuesta válida, con las respuestas ya codificadas |
| `codigo/01_limpiar_datos.py` | Limpieza y codificación (de `raw` a `clean`) |
| `codigo/02_figuras.py` | Genera las 9 figuras a partir de `clean` |
| `figuras/` | Las 9 figuras en PNG y `figuras_cafeterias.pdf` con las 9 páginas |

## Datos y reglas de limpieza

- La base tiene **16 locales**; **15 tienen respuesta válida** (6 dentro y 9 fuera). **Doppio Café** figura como
  cerrado permanentemente: se conserva en `locales_limpio.csv` para trazabilidad, pero no tiene respuestas y no entra en las figuras.
- La zona sale de la columna "¿Dentro del Park Way?" del mapa final y se verifica contra la respuesta de la encuesta
  (el script se detiene si no coinciden).
- Las preguntas de opción múltiple se convierten en columnas 0/1 (por ejemplo, `cliente_oficinas`, `metodo_v60`).
  El formulario pedía marcar hasta tres tipos de cliente, pero 8 de los 15 locales marcaron más; por eso las figuras
  cuentan menciones por local y no porcentajes de clientes.
- "Otras cafeterías a 400 m o menos" (Figura 7) se calcula con las coordenadas del mapa, en línea recta, contando solo
  los otros locales con respuesta válida.
- Todas las medidas son **estimaciones declaradas por el encargado**, no mediciones. Con 6 y 9 locales las
  comparaciones son descriptivas: no hay pruebas de hipótesis ni correlaciones.

## Figuras

1. Qué tan importante fue cada factor al escoger el lugar (promedio por zona)
2. Clientela frecuente según el encargado
3. Parte de los clientes que viene a propósito desde fuera del barrio
4. Cómo llega la mayoría de los clientes
5. Franja de mayor afluencia declarada (entre semana y fin de semana)
6. Tiempo que se queda un cliente en el local
7. Aglomeración y clientela que llega a propósito (exploratoria, sin prueba estadística)
8. Permanencia declarada según la clientela universitaria
9. Métodos de preparación que ofrecen

Accesibilidad: como el rojo y el verde pueden confundirse con algunas formas de daltonismo, las barras "fuera" llevan
rayado, los puntos "fuera" son rombos, y cada barra muestra su conteo ("k de n").
